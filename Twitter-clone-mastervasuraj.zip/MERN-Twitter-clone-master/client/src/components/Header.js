import React from "react";
import { Link } from "react-router-dom";
import { BsTwitter } from "react-icons/bs";

function Header() {
  return <div className="header"></div>;
}

export default Header;
